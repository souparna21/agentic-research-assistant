Test Paper - RAG Fixture 

Abstract: A minimal test PDF for offline smoke tests. 

Section 1: Introduction Retrieval-augmented generation (RAG) combines parametric and non-parametric memory. 

Section 2: Methods We index passages into FAISS and retrieve the top-k for each query. 

Section 3: Results Retrieval accuracy improves with domain-specific embeddings. 
